<?php
declare(strict_types=1);

return [
    'app_name' => 'Webkitti Automation Hub',
    'timezone' => 'Asia/Kolkata',
    'admin_password' => '123!@#qwe',

    // Website -> Gmail -> ChatGPT Work bridge.
    'mail_to' => 'comread7800@gmail.com',
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_username' => 'rs78005142@gmail.com',
    'smtp_app_password' => 'wqin temx sjef dnmw',
    'mail_from' => 'rs78005142@gmail.com',
    'mail_from_name' => 'Prompt Bridge',
    'cron_secret' => '2627484849jdjyr64hejde63d@#$%jdd',
    'message_tag' => 'SOCIAL_AUTOMATION',

    // Keep "metricool" until direct Instagram MCP has passed a real test.
    // Then change to "instagram_mcp".
    'publisher_mode' => 'metricool',

    // Public HTTPS URL where this ONE social-scheduler folder is deployed.
    // Example: https://iwebry.com/social-scheduler
    'public_base_url' => 'https://iwebry.com/social-scheduler/',

    // Direct Instagram MCP / Meta app settings.
    'instagram_app_id' => '1073294802083224',
    'instagram_app_secret' => '3c5e9ff57a755fdd3cd1913a58744ee0',
    'instagram_redirect_uri' => 'https://iwebry.com/social-scheduler/instagram.php?action=oauth_callback',
    'instagram_scopes' => [
        'instagram_business_basic',
        'instagram_business_content_publish',
    ],
    'graph_api_version' => 'v26.0',
    'mcp_api_key' => '1363dhdheeyeyenndeh%^JYHH&**dkdkdn',
    'allowed_origins' => [],

    // Local data/media.
    'storage_path' => __DIR__ . '/storage',
    'media_path' => __DIR__ . '/media',
    'media_max_bytes' => 12 * 1024 * 1024,
];
